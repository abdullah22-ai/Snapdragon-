# FieldLens Zero — 90-second demo script

## 0:00–0:12 — The failure condition
“During a flood, critical information may arrive as one photo and a voice note—while the network is down. Cloud AI cannot help if it cannot be reached. FieldLens Zero starts from that failure condition.”

Show **Offline mode** and Snapdragon edge status.

## 0:12–0:30 — Mixed evidence
Upload a flood or blocked-road image and leave the sample note visible.

“This responder has a photo, a multilingual voice transcript, a blocked route, two stranded families, and a time-sensitive insulin need. The evidence stays on this PC.”

Click **Analyze on device**.

## 0:30–0:50 — Actionable, not conversational
“The local pipeline transcribes, translates, grounds visual and text evidence, and separates observations from inference. Instead of a paragraph, it creates a structured incident: people affected, deadline, blocked route, priority, and missing facts.”

## 0:50–1:08 — Safety and privacy
“FieldLens Zero does not autonomously dispatch help. High-risk actions remain locked behind a human-verification gate. Faces, phone numbers, and sensitive identifiers are redacted before sharing. The proof ledger records the model version, edits, and approvals.”

## 1:08–1:23 — The innovation
“The key output is an offline continuity packet: a small signed record that can travel by QR, USB, Bluetooth, or local network. Raw evidence remains local by default. Response work continues even when the cloud disappears.”

Click **Export handoff packet**.

## 1:23–1:30 — Snapdragon close
“On a Snapdragon-powered HP PC, the NPU sustains private multimodal inference while the CPU protects the workflow. FieldLens Zero turns the laptop into a crisis operations room that travels anywhere.”

## Judge questions

**Is the prototype using real models?**  
The UI demonstrates the workflow. The production adapter defines ONNX/QNN interfaces. Final models require licence and operator-compatibility tests and target-device benchmarks. Do not claim benchmarks before testing.

**Why not use a phone?**  
A laptop provides sustained power, local storage, a large multi-evidence review surface, keyboard correction, peripheral connectivity, and a better base for an operations team. Phones can collect evidence; the PC is the verification and coordination hub.

**How do you prevent harmful recommendations?**  
Constrained schemas, evidence/inference separation, missing-information checks, deterministic policy rules, uncertainty, an append-only ledger, and mandatory human confirmation.

**What is novel?**  
The operational unit is the continuity packet—not a chat response. It is built for disconnected transfer, privacy minimisation, provenance, human verification, and later synchronisation.
