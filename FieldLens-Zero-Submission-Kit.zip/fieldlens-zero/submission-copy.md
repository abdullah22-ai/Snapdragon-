# FieldLens Zero — Copy-ready submission text

> Adapt wording to the exact form limits. Verify all claims before the one allowed submission.

## Project title
FieldLens Zero — No-cloud crisis intelligence for Snapdragon-powered HP PCs

## Tagline
When the network fails, a Snapdragon-powered HP PC becomes a private, multilingual disaster operations room.

## Short description (~75 words)
FieldLens Zero turns mixed disaster-zone evidence—photos, voice notes, and text—into a verified, privacy-protected action packet entirely on a Snapdragon-powered HP PC. Local AI transcribes, translates, grounds facts, detects urgent needs, redacts sensitive information, and proposes an action sequence. A mandatory human-verification gate prevents autonomous dispatch. Compact signed packets can move by QR, USB, Bluetooth, or local network, allowing response work to continue when cloud connectivity is unavailable.

## Problem statement (~150 words)
During floods, fires, landslides, and other emergencies, critical reports arrive as unstructured photos, multilingual voice messages, and incomplete notes. Responders must translate, prioritise, protect personal information, and transfer this material while connectivity may be unstable or absent. Most AI tools depend on the cloud, exposing sensitive data and failing at the worst moment. FieldLens Zero addresses that continuity gap. It runs locally on a Snapdragon-powered HP PC and converts field evidence into an urgency-ranked, privacy-protected incident packet. The system distinguishes evidence from inference, highlights missing information, requires human confirmation for high-risk decisions, and exports a small packet that can be carried through offline channels. Raw evidence stays on the device by default.

## Innovation (~200 words)
FieldLens Zero is not another emergency chatbot. Its core invention is the offline continuity packet: a portable, signed record containing structured facts, evidence hashes, translation, urgency, requested resources, uncertainty, privacy state, and human-verification status. This packet lets verified intelligence move between disconnected teams without automatically exposing raw photos or audio.

The system combines multimodal understanding with an explicit safety architecture. It separates observed evidence from AI inference, performs local PII redaction, shows confidence and missing facts, and locks high-risk exports until a responder verifies location, consent, and route safety. A proof ledger records model version, edits, approvals, and packet hashes.

Snapdragon heterogeneous compute makes the concept practical on a laptop: quantized speech, translation, vision, and compact language models can be assigned across NPU, GPU, and CPU while preserving battery and keeping data private. Adaptive `fast`, `balanced`, and `deep` profiles respond to urgency, battery, and thermal conditions. The result is not simply offline AI; it is operational continuity under failure.

## Technical implementation (~250 words)
The intended Windows-on-Snapdragon build uses a modular ONNX pipeline. Audio is processed by a quantized Whisper-family speech model and an Indic-language translation model. An ONNX-compatible compact vision model extracts observable features from images. A compact instruction model produces a constrained incident JSON document rather than free-form advice. OpenCV and local NER/pattern rules detect and redact faces, phone numbers, identification numbers, and addresses.

ONNX Runtime sessions prefer the Qualcomm QNN execution provider, with GPU or CPU fallbacks for unsupported operators. Models remain resident between incidents, static tensor shapes are used where practical, and separate profiles trade speed, depth, and power. The CPU handles orchestration, deterministic safety rules, encryption, and packet signing.

Raw evidence stays in an encrypted local session. The system records evidence hashes and distinguishes model observations from responder-confirmed facts. A rule-based layer ranks urgency and identifies missing information. The interface presents every critical field for human review. Only verified packets are marked operational. Raw evidence is excluded by default; approved packets can move by QR, USB, Bluetooth, or local network.

The prototype demonstrates intake, local-analysis flow, safety messaging, proof ledger, and packet export. Final performance will be benchmarked on the target Snapdragon-powered HP PC; proposed latency and energy figures are targets, not unverified claims.

## Snapdragon optimisation (~150 words)
FieldLens Zero is designed around Snapdragon PC strengths rather than merely being compatible. Sustained quantized inference is routed to the NPU through the Qualcomm QNN execution provider. Selected visual operators can use the GPU, while the CPU manages orchestration, redaction policy, cryptography, and packet creation. Models are cached to reduce startup cost. Static shapes, quantization, operator fusion where supported, and shared-buffer techniques will be evaluated during target-device optimisation. Three execution profiles adapt to battery, thermals, and incident urgency. Local processing avoids network latency, cloud cost, and unnecessary transfer of sensitive emergency evidence. The target package is an ARM64 Windows offline installer with a CPU fallback for development and degraded operation.

## Deployment and accessibility (~120 words)
The prototype is a self-contained offline web interface; the production version is planned as an ARM64 Windows application with a bundled model set and no mandatory sign-in. Large targets, high contrast, visible keyboard focus, plain-language warnings, and keyboard navigation support use in demanding environments. Language modules can be installed for the relevant region. Responders can correct model outputs, and the system continues with manual entry if a model is unavailable. Handoff packets are small and transport-independent. The interface never relies on colour alone to communicate risk.

## Impact
FieldLens Zero reduces the time between fragmented evidence and a verified response while keeping sensitive data local. Initial users could include disaster-response teams, health camps, campus safety groups, and humanitarian organisations in low-connectivity environments.

## Current status
A working interactive prototype, production-oriented inference architecture, packet schema, safety model, evaluation plan, demonstration script, and editable pitch deck have been created. Hardware benchmarks and field validation remain future work and will not be represented as completed until measured.

## Final declaration checklist
- [ ] I meet all eligibility requirements and have read the complete Official Rules.
- [ ] I understand, tested, and can explain every submitted component.
- [ ] I reviewed licences for all code and models.
- [ ] I removed or corrected every unsupported claim.
- [ ] I accurately disclosed AI assistance or third-party components if asked.
- [ ] I checked every form field because the submission cannot be edited.
- [ ] I am submitting only once.
