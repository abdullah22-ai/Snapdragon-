# FieldLens Zero — Technical architecture

## System boundary
FieldLens Zero functions with the network disabled. Raw evidence, model inference, redaction, incident storage, and audit events remain on the PC. Export is a deliberate human action.

```text
Photo / audio / text
        │
        ▼
Encrypted local session ──► evidence hash + provenance
        │
        ▼
PII pre-scan ──► face / phone / ID / address flags
        │
        ├──► Speech recognition ─► language ID ─► translation
        ├──► Vision grounding ───► observable facts
        └──► Text parser ────────► entities + needs + time constraints
                         │
                         ▼
                Evidence fusion schema
                         │
                         ▼
         Urgency policy + missing-information checks
                         │
                         ▼
               Human verification gate
                         │
                         ▼
       Signed continuity packet (raw media excluded by default)
```

## Compute placement
| Stage | Preferred processor | Reason |
|---|---|---|
| Quantized speech | NPU/QNN | Sustained tensor workload and efficiency |
| Translation and compact LLM | NPU/QNN | Local token generation and privacy |
| Vision encoder | NPU, selected GPU fallback | Parallel visual operators |
| Decode and deterministic redaction | CPU/GPU | Mature operators and policy control |
| Orchestration, validation, encryption | CPU | Deterministic execution |

No unsupported claim is made that every named model compiles without modification for every Snapdragon PC. Integration must test operator coverage and adapt models accordingly.

## Incident schema
```json
{
  "packet_version": "0.1",
  "incident_id": "local-uuid",
  "created_at": "ISO-8601",
  "evidence": [{"sha256": "...", "type": "image", "shared": false}],
  "observations": [{"claim": "bridge approach flooded", "source": "text", "confidence": 0.92}],
  "inferences": [{"claim": "alternate route required", "confidence": 0.74}],
  "needs": [{"type": "medicine", "detail": "insulin", "deadline": "6h"}],
  "priority": {"level": "high", "reasons": ["time-sensitive medicine"]},
  "privacy": {"pii_detected": true, "redacted": true},
  "missing_information": ["coordinates", "patient consent"],
  "verification": {"status": "pending", "verified_by": null},
  "model_manifest": [{"name": "speech", "version": "candidate"}],
  "ledger_hash": "..."
}
```

## Safety invariants
1. A model output is never silently converted into a responder-confirmed fact.
2. High-risk packets cannot be marked dispatch-ready while critical fields are missing.
3. Raw evidence is excluded from export unless explicitly selected.
4. Every packet includes model and policy versions.
5. CPU/manual pathways remain available when accelerated inference fails.
6. Suggested actions are informational; trained responders retain authority.

## Benchmark protocol
Use the target Snapdragon-powered HP PC in airplane mode. Record Windows version, firmware, power profile, model hash, quantization, execution provider, and ambient conditions. Run at least five cold and twenty warm trials per profile. Report median and p95 latency, peak memory, energy per incident, and sustained thermal behaviour. Compare QNN routing with CPU fallback while keeping model and inputs constant.
