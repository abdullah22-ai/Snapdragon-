"""FieldLens Zero production-oriented edge pipeline skeleton.

Default adapters are deterministic so the project runs without model weights.
Replace them with licensed ONNX models after Qualcomm QNN compatibility tests.
No network calls are made.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from typing import Any, Protocol
import json, re, uuid

class PlannerAdapter(Protocol):
    def structure(self, text: str, observations: list[dict[str, Any]]) -> dict[str, Any]: ...

@dataclass
class Verification:
    status: str = "pending"
    required: list[str] = field(default_factory=lambda: ["coordinates", "consent", "route_safety"])
    verified_by: str | None = None

@dataclass
class IncidentPacket:
    packet_version: str
    incident_id: str
    created_at: str
    evidence: list[dict[str, Any]]
    observations: list[dict[str, Any]]
    inferences: list[dict[str, Any]]
    needs: list[dict[str, Any]]
    priority: dict[str, Any]
    privacy: dict[str, Any]
    missing_information: list[str]
    verification: Verification
    model_manifest: list[dict[str, str]]
    ledger_hash: str = ""
    def seal(self) -> "IncidentPacket":
        payload = asdict(self); payload["ledger_hash"] = ""
        self.ledger_hash = sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        return self

PHONE = re.compile(r"(?<!\d)(?:\+91[-\s]?)?[6-9]\d{9}(?!\d)")
EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")

def redact_text(text: str) -> tuple[str, list[str]]:
    findings: list[str] = []
    if PHONE.search(text): findings.append("phone"); text = PHONE.sub("[REDACTED PHONE]", text)
    if EMAIL.search(text): findings.append("email"); text = EMAIL.sub("[REDACTED EMAIL]", text)
    return text, findings

def file_evidence(path: Path, share: bool = False) -> dict[str, Any]:
    return {"name": path.name, "sha256": sha256(path.read_bytes()).hexdigest(), "type": path.suffix.lstrip(".") or "file", "shared": share}

class DemoPlanner:
    """Deterministic runnable adapter; not represented as trained inference."""
    def structure(self, text: str, observations: list[dict[str, Any]]) -> dict[str, Any]:
        lower = text.lower(); urgent = any(x in lower for x in ("insulin", "trapped", "stranded", "fire", "bleeding"))
        needs = []
        if "insulin" in lower: needs.append({"type": "medicine", "detail": "insulin", "deadline": "6h" if "six hours" in lower else None})
        if "flood" in lower or "bridge" in lower: needs.append({"type": "access", "detail": "safe alternate route", "deadline": None})
        return {"observations": observations + [{"claim": text, "source": "field_note", "confidence": 1.0}], "inferences": [{"claim": "alternate route may be required", "confidence": 0.74}] if "bridge" in lower else [], "needs": needs, "priority": {"level": "high" if urgent else "normal", "reasons": ["time-sensitive need"] if urgent else []}, "missing_information": ["coordinates", "patient consent", "route safety"] if urgent else ["coordinates"]}

def build_packet(note: str, evidence_paths: list[Path] | None = None, planner: PlannerAdapter | None = None) -> IncidentPacket:
    protected, pii = redact_text(note); structured = (planner or DemoPlanner()).structure(protected, [])
    return IncidentPacket("0.1", str(uuid.uuid4()), datetime.now(timezone.utc).isoformat(), [file_evidence(p) for p in (evidence_paths or [])], structured["observations"], structured["inferences"], structured["needs"], structured["priority"], {"pii_detected": bool(pii), "pii_types": pii, "redacted": bool(pii), "cloud_requests": 0}, structured["missing_information"], Verification(), [{"name": "demo-deterministic-planner", "version": "0.1"}]).seal()

if __name__ == "__main__":
    sample = "Bridge near Rampur is flooded. Two families are stranded. Call 9876543210. An elderly person needs insulin within six hours."
    print(json.dumps(asdict(build_packet(sample)), indent=2))
