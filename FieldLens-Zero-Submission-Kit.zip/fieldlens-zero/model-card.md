# FieldLens Zero — System and model card

## Intended use
Decision support for trained responders who need to structure mixed evidence in low-connectivity environments. Outputs require human review.

## Out of scope
- autonomous emergency dispatch;
- medical diagnosis or treatment selection;
- identity recognition;
- legal evidence certification;
- prediction of individual behaviour;
- use as the sole basis for denying or prioritising lifesaving support.

## Known limitations
- Speech accuracy may fall with noise, code-switching, rare dialects, stress, or multiple speakers.
- Translation may remove local nuance.
- Vision models can miss hazards or infer objects that are not present.
- Incomplete reports can produce incorrect urgency.
- PII detection cannot guarantee perfect redaction.
- Operator support and performance vary by model, quantization, runtime, driver, and Snapdragon PC generation.
- The browser prototype demonstrates workflow; it does not prove final model accuracy or hardware performance.

## Human controls
- Critical claims show source and confidence.
- Observations and inferences are stored separately.
- High-risk exports require confirmation of location, consent, and safety.
- Responders can correct fields and use manual entry.
- Raw media is excluded from packet export by default.

## Evaluation slices
Test by language, accent, background noise, lighting, weather, image quality, incident type, and disability/access need. Track false negatives for urgent medical needs and PII redaction separately because aggregate accuracy can hide harmful failures.

## Data governance
Use consented or appropriately licensed test data. Do not train on real incident data without a documented lawful basis, minimisation, retention controls, and participant protection. Record model and dataset versions.

## Transparency
Every packet should include model identifiers, policy version, time, evidence hashes, human edits, verification state, and whether accelerated or fallback execution was used.
