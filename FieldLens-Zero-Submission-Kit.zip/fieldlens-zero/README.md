# FieldLens Zero

**A no-cloud, multilingual crisis intelligence system designed for Snapdragon-powered HP PCs.**

FieldLens Zero turns mixed field evidence—photos, voice notes, and text—into a structured, privacy-protected incident packet. It is designed for disaster-response situations where internet connectivity is unavailable, unreliable, expensive, or unsafe.

## Why it is different

Most emergency AI products assume a cloud connection. FieldLens Zero assumes the opposite. A Snapdragon-powered HP PC becomes a portable operations room that can:

1. transcribe and translate multilingual field audio locally;
2. ground claims in image and text evidence;
3. redact faces, phone numbers, and other sensitive details before sharing;
4. produce an urgency-ranked action plan with confidence and missing-information flags;
5. require human confirmation before dispatch; and
6. export a small, signed offline handoff packet that can move by USB, QR, Bluetooth, or local network.

The product is not an autonomous emergency dispatcher. It is a decision-support and continuity tool with a mandatory human-verification gate.

## Prototype

Open `index.html` in any modern browser. The prototype runs without a server or network connection and includes evidence upload, a simulated on-device analysis flow, human-verification warnings, a privacy boundary, proof ledger, and export of a portable JSON handoff packet.

The browser prototype demonstrates workflow and interaction design. The production adapter in `src/edge_pipeline.py` defines inference interfaces for ONNX Runtime/QNN deployment. Model weights are intentionally not bundled.

## Snapdragon optimisation plan

- **NPU-first:** quantized ONNX models routed to the Qualcomm QNN execution provider where available.
- **Heterogeneous compute:** NPU for sustained inference, GPU for selected vision operators, CPU for orchestration and redaction rules.
- **Shared model residency:** keep pipeline stages loaded between incidents.
- **Adaptive profiles:** `fast`, `balanced`, and `deep` modes based on battery, thermals, and urgency.
- **Offline by design:** inference, storage, redaction, and audit logging occur locally.
- **ARM64 packaging:** Windows on Snapdragon target with CPU fallback for development.

All performance figures in the proposal are validation targets, not measured claims. Benchmark them on the final HP device before representing them as achieved.

## Suggested open-source model stack

- Quantized Whisper-family model for offline speech recognition.
- IndicTrans2 or an equivalent open-source translation model for Indian languages.
- Florence-2 / MobileCLIP-class vision model exported to ONNX.
- Phi-3.5 Mini / Llama-class compact instruct model for structured summarisation.
- OpenCV plus local pattern/NER rules for PII redaction.

Before submission, confirm each model's licence and Snapdragon/QNN operator compatibility. The rules permit Qualcomm AI Hub models or other open-source platforms, but freeze the model list only after target-device validation.

## Run

```bash
python -m http.server 8080
# Open http://localhost:8080/fieldlens-zero/
python fieldlens-zero/src/edge_pipeline.py
```

## Folder guide

- `index.html` — self-contained interactive prototype
- `src/edge_pipeline.py` — model orchestration skeleton
- `proposal.pdf` / `proposal.md` — challenge proposal
- `submission-copy.md` — copy-ready form answers
- `architecture.md` — technical and safety design
- `demo-script.md` — 90-second judge demo
- `model-card.md` — limitations and evaluation plan
- `pitch-deck.pptx` — editable presentation

## Important submission note

Only submit after you have reviewed, understood, tested, and adapted the work. Do not make unsupported benchmark claims. If the form asks about AI assistance, collaborators, third-party code, or model licences, answer accurately. The organiser's complete Official Rules control eligibility.
