from pathlib import Path
from html import escape
import re
src=Path('/data/fieldlens-zero/proposal.md').read_text()
blocks=[]; in_list=False
for raw in src.splitlines():
    line=raw.rstrip()
    if not line:
        if in_list: blocks.append('</ul>'); in_list=False
        continue
    if line.startswith('# '):
        blocks.append(f'<h1>{escape(line[2:])}</h1>')
    elif line.startswith('## '):
        blocks.append(f'<h2>{escape(line[3:])}</h2>')
    elif line.startswith('### '):
        blocks.append(f'<h3>{escape(line[4:])}</h3>')
    elif re.match(r'^\d+\. ',line):
        if in_list: blocks.append('</ul>'); in_list=False
        blocks.append(f'<p class="step"><b>{escape(line.split(". ",1)[0])}.</b> {escape(line.split(". ",1)[1])}</p>')
    elif line.startswith('- '):
        if not in_list: blocks.append('<ul>'); in_list=True
        blocks.append(f'<li>{escape(line[2:])}</li>')
    else:
        if in_list: blocks.append('</ul>'); in_list=False
        t=escape(line)
        t=re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',t)
        blocks.append(f'<p>{t}</p>')
if in_list: blocks.append('</ul>')
body='\n'.join(blocks)
html=f'''<!doctype html><html><head><meta charset="utf-8"><style>
@page{{size:A4;margin:18mm 17mm 18mm}}*{{box-sizing:border-box}}body{{font-family:Arial,sans-serif;color:#18302a;font-size:10.5pt;line-height:1.46;margin:0}}h1{{font-size:30pt;line-height:1.04;margin:0;color:#10211d;letter-spacing:-1px}}h1+ h2{{font-size:14pt;color:#2b7a61;border:0;margin:8px 0 30px;font-weight:500}}h2{{font-size:17pt;line-height:1.15;margin:24px 0 8px;padding-top:8px;border-top:1px solid #cfe0da;color:#10211d;break-after:avoid}}h3{{font-size:11pt;text-transform:uppercase;letter-spacing:.08em;color:#2b7a61;margin:16px 0 6px;break-after:avoid}}p{{margin:0 0 8px}}ul{{margin:5px 0 10px;padding-left:19px}}li{{margin:0 0 4px}}strong{{color:#10211d}}.step{{border-left:3px solid #5dd3a3;padding:4px 0 4px 10px;margin:7px 0}}body:before{{content:'SNAPDRAGON AI LAB · BUILD & PRESENT';display:block;color:#2b7a61;font-size:8pt;font-weight:700;letter-spacing:.14em;margin-bottom:20px}}body:after{{content:'FieldLens Zero · Submission proposal';position:fixed;bottom:-10mm;left:0;color:#6f827d;font-size:8pt}}
</style></head><body>{body}</body></html>'''
Path('/data/fieldlens-zero/proposal.html').write_text(html)
